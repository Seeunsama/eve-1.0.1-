# -*- coding: utf-8 -*-
# import hack so modules importing this package can still import BytesIO from
# standard library's io module
from io import BytesIO  # noqa
