.. _changelog:

.. include:: ../CHANGES.rst
