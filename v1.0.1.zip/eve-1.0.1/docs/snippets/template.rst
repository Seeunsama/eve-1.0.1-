Snippet Template
================
by Firstname Lastname

This is a snippet template. Put your snippet explanation here. If this is going
to be long, make sure to split it into paragraphs for enhanced reading
experience. Make your code snippet follow, like so:

.. code-block:: python

    from eve import Eve

    # just an example of a code snippet
    app = Eve()
    app.run()

Add closing comments as needed.
