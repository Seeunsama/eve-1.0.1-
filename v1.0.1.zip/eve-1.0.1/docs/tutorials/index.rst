.. _tutorials:

Tutorials
=========

.. toctree::
   :maxdepth: 2

   account_management
   custom_idfields

Learn Eve at TalkPython Training
--------------------------------
There is a 5 hours-long Eve course available for you at the fine TalkPython
Training website. The teacher is Nicola, Eve author and maintainer. Taking this
course will directly support the project.

- `Take the Eve Course at TalkPython Training <https://training.talkpython.fm/courses/explore_eve/eve-building-restful-mongodb-backed-apis-course>`_
